# Catalogue v2 (`hikes2-<x>_<y>.json` + `hikes2-index.json`) — OSM + IGN, tout précalculé

Remplace les `hikes-<région>.json` (v1, décrits dans `FORMAT.md`, conservés). Sources : © contributeurs OpenStreetMap (ODbL) ;
IGN BD TOPO® `itineraire_autre` (Licence Ouverte 2.0, « © IGN ») ; altitudes **IGN BD ALTI® 25 m** (Licence Ouverte 2.0,
citer « IGN – BD ALTI® »). Tout est précalculé.

## Découpage spatial
Cases de **0,5°** (`cellDegrees`). Une route est rangée **une seule fois**, dans la case du centre de sa bbox
(`x = floor(lon/0,5)`, `y = floor(lat/0,5)`, fichier `hikes2-<x>_<y>.json`) : pas de duplication, un grand GR n'est pas copié
dans 100 fichiers. `hikes2-index.json` : `{"version":2,"generated","cellDegrees":0.5,"routes":N,"files":[{"file","cell":[x,y],
"routes","bytes","gzipBytes","bbox":[minLon,minLat,maxLon,maxLat]}]}`, où `bbox` est l'union des bbox des routes du fichier (elle
dépasse la case pour les longues routes). **Recherche** : charger l'index (≈ 40 Ko), ouvrir les fichiers dont `bbox` coupe la zone,
filtrer sur la `bbox` de chaque route. Les routes sont **déjà fusionnées** (plus de doublon entre régions, plus de fusion OSM/IGN
dans l'app). Fichier : `{"version":2,"source":"osm+ign","cell":[x,y],"generated","routes":[…]}`.

## Route (champs v1 conservés ; ajouts marqués ➕)
| Champ | Sens |
|---|---|
| `id` | `osm:r<id>` ou `ign:<nom normalisé>:<plus petite cleabs>` (comme `HikeBuilder`) |
| `name` | peut être `""` (IGN sans toponyme : l'app affiche « Sentier sans nom ») ; `ref`, `network` (`none` pour l'IGN), `symbol`, `operator`, `website` comme en v1 |
| ➕ `source` | `osm`, `osm+ign` (relation OSM dont le tracé IGN couvre ≥ 80 % à 25 m, longueur ×0,6–1,6) ou `ign` |
| ➕ `path` | **tracé de référence**, polyligne précision 6 (lat,lon), un seul morceau dans l'ordre de parcours. Chaînage corrigé : départs multiples, ordre qui minimise les trous ; si un tronçon continu porte ≥ 75 % de la longueur il est le `path` (raccords/accès détachés écartés → `stray`) |
| ➕ `gaps` | trous > 100 m comblés par un segment droit dans `path` (0 si le `path` est continu) |
| ➕ `stray` | (absent si 0) nombre de morceaux détachés écartés du `path` |
| `lines` | **absent sauf si `stray` ou `gaps` > 0** : alors tronçons réels (mêmes polylignes qu'en v1). **Absent ⇒ géométrie = `path`** |
| `lengthM` | somme des tronçons (hors raccord de boucle) + `closure` ; sur la géométrie |
| ➕ `closure` | (absent sauf boucle complétée) longueur en m du raccord routé ajouté en fin de `path` ; l'app peut afficher « boucle complétée » |
| `loop` / ➕ `kind` | `kind` = `loop` (drapeau OSM, ou départ-arrivée < 150 m, ou < 500 m **et** < 10 % du chemin, ou boucle complétée), `outAndBack` (≥ 80 % du retour repasse à < 25 m du début : 9 routes), sinon `oneWay` ; `loop == (kind == "loop")` |
| ➕ `startEndM` | distance départ→arrivée du `path` (entier) |
| ➕ `retrace` | part (0–1) du retour qui repasse sur l'aller |
| ➕ `ascentM`, `descentM` | montée / descente cumulées (entiers) : altitudes tous les 25 m (4 000 points au plus), lissage par moyenne mobile sur 5 points puis paliers de 3 m = `HikeElevation.climb` |
| ➕ `profile` | 40 altitudes entières, réparties régulièrement le long du `path` |
| ➕ `minM`, `maxM` | altitudes extrêmes |
| `bbox` | lon/lat sur toute la géométrie (path + lines) |

Altitudes **absentes** (383 routes, hors métropole : Antilles, Guyane, Réunion, Mayotte). Durée et difficulté : à calculer dans l'app.

## Précision des altitudes
BD ALTI = **modèle de terrain** (sol nu) à pas de 25 m, interpolation bilinéaire ; précision verticale IGN ≈ 1 à 7 m selon le relief,
mais la **montée est lissée par le pas de 25 m** (petits ressauts perdus, sous-estimation possible en terrain très accidenté).
Le Copernicus GLO-30 (modèle de *surface*, canopée comprise) a été **écarté** : +8 à +10 m en forêt, montée +30 à 50 %.
Contrôle : Denecourt 1 → 53 / 59 m (service IGN RGE ALTI : 55 / 61 m).

## Boucles complétées
Candidats : pas boucle, départ-arrivée du `path` entre 150 m et 1 km **et** ≤ 10 % de la longueur. Raccord routé (IGN
`bdtopo-valhalla`, `pedestrian`, `shortest`) ; gardé s'il fait ≤ 1 km et repasse sur < 30 % du tracé (couloir 25 m).
